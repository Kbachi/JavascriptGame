/*The Game Project Part 7 - Game Mechanics*/

var gameChar_x;
var gameChar_y;
var floorPos_y;
var isFalling;
var isRight;
var isLeft;
var cloud;
var mountains; 
var isFound;
var flagpole;
var isReached;
var canyons;
var collectables;
var gameScore;
var player_speed;
var crown_size;
var flagpole_offset_x;
var flagpole_offset_y;
var isPlummeting;
var trees_x;
var treesPos_x;
var treePos_y;
var cameraPos_x;
var timeLimit;
var startTimer;
var timePassed;
var timeLeft;
var gameOver;
var levelComplete;
var pause;

function setup() {
    createCanvas(1024, 576);
    floorPos_y = height * 3 / 4;
    gameChar_x = width / 8;
    gameChar_y = floorPos_y;
    player_speed = 8;
    crown_size = 50;
    flagpole_offset_x = 3500;
    flagpole_offset_y = 430;
    treePos_y = height/2;
    cameraPos_x = 0;
    gameScore = 0;
    timeLimit = 25000;
    startTimer = millis();
    gameOver = false;
    lFevelComplete = true;
    pause = false;

  
    isFalling = false;
    isRight = false;
    isLeft = false;
    isPlummeting = false;
  
    canyons = [
      {x_pos: 220, width: 125},
      {x_pos: 900, width: 100},
      {x_pos: 500, width: 80},
      {x_pos: 1200, width: 90},
      {x_pos: -990, width: 570},
      {x_pos: 1500, width: 100},
      {x_pos: 1800, width: 40},
      {x_pos: 2100, width: 90},
      {x_pos: 2600, width: 70},
      {x_pos: 3000, width: 110},
      {x_pos: 3300, width: 90},
    ]
  
    mountains = [
      {x_pos: 0},
      {x_pos: 1200},
      {x_pos: 2100},
      {x_pos: 2800},
      {x_pos: 3100}
    ]  
     
    trees_x = [800, 500, -90, 950, 1200, 1500, 1800, 2100, 2400, 2550, 2710, 2950, 3200, 3420]
  
    cloud = [
      { x_pos: 210, y_pos: 100 },
      { x_pos: 550, y_pos: 160 },
      { x_pos: 890, y_pos: 85 },
      { x_pos: 1100, y_pos: 150 },
      { x_pos: 1450, y_pos: 160 },
      { x_pos: 1790, y_pos: 100 },
      { x_pos: 2000, y_pos: 100 },
      { x_pos: 2800, y_pos: 100 },
      { x_pos: 3000, y_pos: 150 },
      { x_pos: 3200, y_pos: 950 },
    ]
    
    collectables = [
      {x_pos: 1478 , y_pos: floorPos_y + - 30, size: crown_size , isFound: false},
      {x_pos: 1200 , y_pos: floorPos_y + - 60, size: crown_size , isFound: false},
      {x_pos: 900 , y_pos: floorPos_y + - 40, size: crown_size , isFound: false},
      {x_pos: 1600 , y_pos: floorPos_y + - 90, size: crown_size , isFound: false},
      {x_pos: 400 , y_pos: floorPos_y + - 30, size: crown_size , isFound: false},
      {x_pos: -440 , y_pos: floorPos_y + - 80, size: crown_size , isFound: false},
      {x_pos: 1800 , y_pos: floorPos_y + - 120, size: crown_size , isFound: false},
      {x_pos: 2100 , y_pos: floorPos_y + - 130, size: crown_size , isFound: false},
      {x_pos: 2500 , y_pos: floorPos_y + - 30, size: crown_size , isFound: false},
      {x_pos: 2800 , y_pos: floorPos_y + - 90, size: crown_size , isFound: false},
      {x_pos: 3100 , y_pos: floorPos_y + - 70, size: crown_size , isFound: false},
      {x_pos: 3400 , y_pos: floorPos_y + - 100, size: crown_size , isFound: false},
      
    ] 
    
  
    flagpole = {
      x_pos: gameChar_x + flagpole_offset_x,
      y_pos: floorPos_y,
      isReached: false
    }
  
  }

///////////DRAWING CODE//////////
function draw() {
  
    //////background
    //fill the sky blue
    background(100, 155, 255);
    
    ///////draws ufo and sun which follows the player
    draw_ufo_sun()
  
    //draw some green ground
    noStroke();
    fill(0, 155, 0);
    rect(0, floorPos_y, width, height - floorPos_y);

    //////////camera movement
    push(); 
    translate(-cameraPos_x,0);

    ///////////mountains
    draw_mountains();

    ////////////tree
    draw_trees();

    ////////////clouds
    draw_clouds();

    ///////////draws canyons
    draw_canyons();

    ////the game character////
    draw_character();

    ////draws flagpole unreached/////
    if (!flagpole.isReached) {
      draw_flagpole_down();
    }
    ////////draws flagpole reached/////
    else {
      draw_flagpole_up();
    }

    ////////////draws crown if not found///
    for (i = 0; i < collectables.length; i++){
        if (!collectables[i].isFound) {
          draw_crown();
      }
    }
  
  ///////////////adjusts character to remain centred on screen
    pop();
    cameraPos_x = gameChar_x - width / 2;

  
    ///////// displays the score in the top left of the screen
    stroke(1)
    fill(0)
    textFont('Silkscreen', 20)
    text("Score:" + gameScore +"/" + collectables.length, width - 1000, 50);
    textSize(0)
    noStroke();
    
    ////////function for time limit mechanics and game over mechanics
    timer();
  
   ///////////checks for players position over canyon//////
    for (i = 0; i < canyons.length; i++){
      if (gameChar_x > canyons[i].x_pos + 3 && gameChar_x < canyons[i].x_pos +3 + canyons[i].width) {
          if (gameChar_y >= floorPos_y) {
          isPlummeting = true;
        }
      }
    }

    ///////////INTERACTION CODE//////////
    //Put conditional statements to move the game character below here
  if (!flagpole.isReached && !gameOver){
    if (isLeft && !isReached && !gameOver) {
      gameChar_x -= player_speed;
    } 
  
    else if (isRight && !isReached && !gameOver) {
      gameChar_x += player_speed;
    }
  }
    for (i = 0; i < collectables.length; i++){
      if (!collectables[i].isFound && dist(gameChar_x, gameChar_y, collectables[i].x_pos, collectables[i].y_pos) < 35) {
        collectables[i].isFound = true;
        gameScore += 1;
      }
    }
  
  
  ////////// game complete screen////
    if (dist(gameChar_x, gameChar_y, flagpole.x_pos, flagpole.y_pos) < 30) {
      flagpole.isReached = true;
      levelComplete = true;
      pause = true;
      fill(60, 60, 60, 200);
      rect(0, 0, windowWidth, windowHeight);
      fill(255, 0, 0);
      textFont("Arial", 95);
      text("🎉You Won!🎉", windowWidth / 7, windowHeight / 3);
      fill(100, 180, 120);
      rect(windowWidth / 2.5, windowHeight / 2.5, 150, 50, 30);
      fill(255, 0, 0);
      textFont("Comic Sans", 22);
      text(" Click to restart", windowWidth / 2.48, windowHeight / 2.28);
      textSize(12)

      /////// Checks if the mouse is over the restarts button
      if (
          mouseX > windowWidth / 2.5 &&
          mouseX < windowWidth / 2.5 + 150 &&
          mouseY > windowHeight / 2.5 &&
          mouseY < windowHeight / 2.5 + 50
      ) {
        
        fill(150, 220, 180);
        rect(windowWidth / 2.5, windowHeight / 2.5, 150, 50, 30);
        fill(255, 0, 0);
        textFont("Comic sans", 22);
        text(" Click to restart", windowWidth / 2.48, windowHeight / 2.28);
        textSize(12);

        ////// Checks for mouse click and restarts the game
        if (mouseIsPressed) {
            setup();
        }
    }
}
    
   ////////// game over screen/////
    if (gameChar_y > floorPos_y + 220) {
        gameOver = true;
        fill(60, 60, 60, 200);
        rect(0, 0, windowWidth, windowHeight);
        fill(255, 0, 0);
        textFont("Comic sans MS", 95);
        text("☠️ Game Over! ☠️", windowWidth / 7, windowHeight / 3);
        fill(100, 180, 120);
        rect(windowWidth / 2.5, windowHeight / 2.5, 150, 50, 30);
        fill(255, 0, 0);
        textFont("Comic Sans ", 22);
        text(" Click to restart", windowWidth / 2.48, windowHeight / 2.28);
        textSize(20);

    if (
        mouseX > windowWidth / 2.5 &&
        mouseX < windowWidth / 2.5 + 150 &&
        mouseY > windowHeight / 2.5 &&
        mouseY < windowHeight / 2.5 + 50
        ) {
           fill(150, 220, 180);
           rect(windowWidth / 2.5, windowHeight / 2.5, 150, 50, 30);
           fill(255, 0, 0);
           textFont("Comic Sans", 22);
           text(" Click to restart", windowWidth / 2.48, windowHeight / 2.28);
           textSize(20);

      if (mouseIsPressed) {
               setup();
            }
        }
    }

}

/////////////function to draw clouds
function draw_clouds(){
    for ( i = 0; i < cloud.length; i++){
    fill(210,195); 
    ellipse(cloud[i].x_pos - 20, cloud[i].y_pos,90, 60);
    ellipse(cloud[i].x_pos - 20, cloud[i].y_pos + 20, 90, 65);
    ellipse(cloud[i].x_pos + 10, cloud[i].y_pos - 10, 90, 65);
    ellipse(cloud[i].x_pos + 20, cloud[i].y_pos, 90, 60);
    ellipse(cloud[i].x_pos + 20, cloud[i].y_pos + 20, 90, 50);
  }
}

//////////function to draw trees
function draw_trees() { 
    for (var i = 0; i < trees_x.length; i++){
    fill(191,120,100); 
    rect(trees_x[i] + 3, treePos_y,25,145);
    triangle(
              trees_x[i] + 26,treePos_y + 95,
              trees_x[i] + 26, treePos_y + 90,
              trees_x[i] + 43,treePos_y + 89
                );

    triangle(trees_x[i] - 19, treePos_y + 146,
             trees_x[i] + 11,treePos_y + 132,
             trees_x[i] + 49,treePos_y + 146
           );

    fill(50,210,30);
    ellipse(trees_x[i] + 12, treePos_y + 7,70,120);
    ellipse(trees_x[i] - 20, treePos_y + 29,50,60);
    ellipse(trees_x[i] + 41, treePos_y + 11,50,90);
    ellipse(trees_x[i] - 17, treePos_y + 3,50,80);
  }
}

function draw_mountains () {
  for (i = 0; i < mountains.length; i++){
        fill(120) 
    triangle(mountains[i].x_pos + 20, 432,
             mountains[i].x_pos +  80, 220,
             mountains[i].x_pos + 180, 432
            );
  
    fill(125);
    triangle(mountains[i].x_pos - 220,432,
             mountains[i].x_pos - 120, 290,
             mountains[i].x_pos - 60, 432
            );
  
    fill(100);
    triangle(mountains[i].x_pos - 110, 432,
             mountains[i].x_pos - 10, 130,
             mountains[i].x_pos + 110, 432
            );
  
    fill(200);
    triangle(mountains[i].x_pos - 33, 200,
             mountains[i].x_pos - 10, 129,
             mountains[i].x_pos + 41, 255
            );
  
    triangle(mountains[i].x_pos - 49, 239,
             mountains[i].x_pos - 10, 129,
             mountains[i].x_pos - 5, 200
            );
  
  }
}

/////////////function to draw canyons//
function draw_canyons(){
  for (i = 0; i < canyons.length; i++) {
    noStroke();
    fill(92, 40, 0);
    rect(canyons[i].x_pos, floorPos_y, canyons[i].width, height - floorPos_y);
  }
}



///checks if character is above the ground//
function draw_character(){
  if (gameChar_y < floorPos_y) {
    gameChar_y += 6;
    isFalling = true;
  } 
  else{
    isFalling = false;
  }
  
  if (isPlummeting) {
      gameChar_y += 7;
    }
  if (isPlummeting){
        isLeft = false;
    }
  if  (isPlummeting){
        isRight = false;
    }
  if (isPlummeting) {
        isFalling = true;
    }    
  
  if (isLeft && isFalling) {
    // add your jumping-left code
    fill(198, 200, 0);
    ellipse(gameChar_x + 1, gameChar_y - 52, 20, 25);
    triangle(
      gameChar_x - 3,
      gameChar_y - 63,
      gameChar_x + 1,
      gameChar_y - 76,
      gameChar_x + 5,
      gameChar_y - 62
    );
    
    fill(255, 0, 0);
    ellipse(gameChar_x + 1, gameChar_y - 74, 5);

    fill(0);
    ellipse(gameChar_x - 5, gameChar_y - 57, 8, 5);
    ellipse(gameChar_x - 3, gameChar_y - 48, 8, 6);

    fill(160, 0, 170);
    beginShape();
    vertex(gameChar_x + 8, gameChar_y - 25);
    vertex(gameChar_x - 8, gameChar_y - 17);
    vertex(gameChar_x - 1, gameChar_y - 11);
    vertex(gameChar_x - 10, gameChar_y - 11);
    vertex(gameChar_x - 15, gameChar_y - 17);
    vertex(gameChar_x - 6, gameChar_y - 25);
    endShape();

    beginShape();
    vertex(gameChar_x + 1, gameChar_y - 25);
    vertex(gameChar_x + 5, gameChar_y - 17);
    vertex(gameChar_x + 5, gameChar_y - 11);
    vertex(gameChar_x + 2, gameChar_y - 11);
    vertex(gameChar_x - 2, gameChar_y - 17);
    vertex(gameChar_x - 5, gameChar_y - 25);
    endShape();
    fill(155);
    ellipse(gameChar_x - 6, gameChar_y - 10, 10, 7);
    ellipse(gameChar_x + 5, gameChar_y - 10, 10, 7);

    fill(4, 9, 196);
    rect(gameChar_x - 18, gameChar_y - 38, 16, 9, 5, 5);
    fill(198, 200, 0);
    ellipse(gameChar_x - 20, gameChar_y - 33, 10, 8);

    fill(4, 9, 196);
    rect(gameChar_x - 5, gameChar_y - 40, 12, 20, 4);
    fill(198, 200, 0);
    ellipse(gameChar_x + 1, gameChar_y - 52, 20, 25);
    triangle(
      gameChar_x - 3,
      gameChar_y - 63,
      gameChar_x + 1,
      gameChar_y - 76,
      gameChar_x + 5,
      gameChar_y - 62
    );
    
    fill(255, 0, 0);
    ellipse(gameChar_x + 1, gameChar_y - 74, 5);

    fill(0);
    ellipse(gameChar_x - 5, gameChar_y - 57, 8, 5);
    ellipse(gameChar_x - 3, gameChar_y - 48, 8, 6);

    fill(160, 0, 170);
    beginShape();
    vertex(gameChar_x + 8, gameChar_y - 25);
    vertex(gameChar_x - 8, gameChar_y - 17);
    vertex(gameChar_x - 1, gameChar_y - 11);
    vertex(gameChar_x - 10, gameChar_y - 11);
    vertex(gameChar_x - 15, gameChar_y - 17);
    vertex(gameChar_x - 6, gameChar_y - 25);
    endShape();

    beginShape();
    vertex(gameChar_x + 1, gameChar_y - 25);
    vertex(gameChar_x + 5, gameChar_y - 17);
    vertex(gameChar_x + 5, gameChar_y - 11);
    vertex(gameChar_x + 2, gameChar_y - 11);
    vertex(gameChar_x - 2, gameChar_y - 17);
    vertex(gameChar_x - 5, gameChar_y - 25);
    endShape();
    fill(155);
    ellipse(gameChar_x - 6, gameChar_y - 10, 10, 7);
    ellipse(gameChar_x + 5, gameChar_y - 10, 10, 7);

    fill(4, 9, 196);
    rect(gameChar_x - 18, gameChar_y - 38, 16, 9, 5, 5);
    fill(198, 200, 0);
    ellipse(gameChar_x - 20, gameChar_y - 33, 10, 8);

    fill(4, 9, 196);
    rect(gameChar_x - 5, gameChar_y - 40, 12, 20, 4);
    
  
  } 
    else if (isRight && isFalling) {
      // add your jumping-right code
      
      fill(198, 200, 0);
      ellipse(gameChar_x + 1, gameChar_y - 52, 20, 25);
      triangle(
      gameChar_x - 3,
      gameChar_y - 63,
      gameChar_x + 1,
      gameChar_y - 76,
      gameChar_x + 5,
      gameChar_y - 62
    );

    fill(255, 0, 0);
    ellipse(gameChar_x + 1, gameChar_y - 74, 5);
    ellipse(gameChar_x + 5, gameChar_y - 57, 8, 5);
    ellipse(gameChar_x + 5, gameChar_y - 48, 8, 6);

    fill(0);
    ellipse(gameChar_x + 5, gameChar_y - 57, 8, 5);
    ellipse(gameChar_x + 5, gameChar_y - 48, 8, 6);

    fill(160, 0, 170);
    beginShape();
    vertex(gameChar_x - 5, gameChar_y - 25);
    vertex(gameChar_x + 8, gameChar_y - 17);
    vertex(gameChar_x + 1, gameChar_y - 11);
    vertex(gameChar_x + 10, gameChar_y - 11);
    vertex(gameChar_x + 15, gameChar_y - 17);
    vertex(gameChar_x + 8, gameChar_y - 25);
    endShape();

    beginShape();
    vertex(gameChar_x - 1, gameChar_y - 25);
    vertex(gameChar_x - 5, gameChar_y - 17);
    vertex(gameChar_x - 5, gameChar_y - 11);
    vertex(gameChar_x - 2, gameChar_y - 11);
    vertex(gameChar_x + 2, gameChar_y - 17);
    vertex(gameChar_x + 5, gameChar_y - 25);
    endShape();
    fill(155);
    ellipse(gameChar_x + 6, gameChar_y - 10, 10, 7);
    ellipse(gameChar_x - 5, gameChar_y - 10, 10, 7);

    fill(4, 9, 196);
    rect(gameChar_x - 5, gameChar_y - 40, 12, 20, 4);

    rect(gameChar_x + 5, gameChar_y - 38, 16, 9, 5, 5);
    fill(198, 200, 0);
    ellipse(gameChar_x + 20, gameChar_y - 33, 10, 8);
  } 
  else if (isLeft) {
    // add your walking left code
    fill(4, 9, 196);
    beginShape();
    vertex(gameChar_x - 5, gameChar_y - 28);
    vertex(gameChar_x - 20, gameChar_y - 25);
    vertex(gameChar_x - 20, gameChar_y - 29);
    vertex(gameChar_x - 5, gameChar_y - 35);
    endShape();

    fill(198, 200, 0);
    ellipse(gameChar_x - 20, gameChar_y - 27, 10, 8);

    fill(160, 0, 170);
    beginShape();
    vertex(gameChar_x, gameChar_y - 25);
    vertex(gameChar_x - 12, gameChar_y - 9);
    vertex(gameChar_x - 16, gameChar_y - 15);
    vertex(gameChar_x - 3, gameChar_y - 28);
    endShape();

    beginShape();
    vertex(gameChar_x - 1, gameChar_y - 25);
    vertex(gameChar_x - 1, gameChar_y - 5);
    vertex(gameChar_x + 4, gameChar_y - 5);
    vertex(gameChar_x + 6, gameChar_y - 25);
    endShape();

    fill(155);
    ellipse(gameChar_x - 15, gameChar_y - 11, 9, 7);
    ellipse(gameChar_x + 1, gameChar_y - 8, 9, 7);

    fill(198, 200, 0);
    ellipse(gameChar_x + 1, gameChar_y - 52, 20, 25);
    triangle(
      gameChar_x - 3,
      gameChar_y - 63,
      gameChar_x + 1,
      gameChar_y - 76,
      gameChar_x + 5,
      gameChar_y - 62
    );
    
    fill(255, 0, 0);
    ellipse(gameChar_x + 1, gameChar_y - 74, 5);

    fill(0);
    ellipse(gameChar_x - 5, gameChar_y - 57, 8, 5);
    ellipse(gameChar_x - 3, gameChar_y - 48, 8, 6);

    fill(4, 9, 196);
    rect(gameChar_x - 5, gameChar_y - 40, 12, 20, 4);
  } 
  else if (isRight) {
    // add your walking right code
    fill(4, 9, 196);
    beginShape();
    vertex(gameChar_x + 5, gameChar_y - 28);
    vertex(gameChar_x + 20, gameChar_y - 25);
    vertex(gameChar_x + 20, gameChar_y - 29);
    vertex(gameChar_x + 5, gameChar_y - 35);
    endShape();

    fill(198, 200, 0);
    ellipse(gameChar_x + 20, gameChar_y - 27, 10, 8);

    fill(160, 0, 170);
    beginShape();
    vertex(gameChar_x, gameChar_y - 25);
    vertex(gameChar_x + 12, gameChar_y - 9);
    vertex(gameChar_x + 16, gameChar_y - 15);
    vertex(gameChar_x + 3, gameChar_y - 28);
    endShape();
    ellipse(gameChar_x + 15, gameChar_y - 11, 9, 7);

    beginShape();
    vertex(gameChar_x + 2, gameChar_y - 25);
    vertex(gameChar_x + 1, gameChar_y - 5);
    vertex(gameChar_x - 4, gameChar_y - 5);
    vertex(gameChar_x - 6, gameChar_y - 25);
    endShape();

    fill(155);
    ellipse(gameChar_x + 15, gameChar_y - 11, 9, 7);
    ellipse(gameChar_x - 1, gameChar_y - 7, 9, 7);

    fill(198, 200, 0);
    ellipse(gameChar_x + 1, gameChar_y - 52, 20, 25);
    triangle(
      gameChar_x - 3,
      gameChar_y - 63,
      gameChar_x + 1,
      gameChar_y - 76,
      gameChar_x + 5,
      gameChar_y - 62
    );
    fill(255, 0, 0);
    ellipse(gameChar_x + 1, gameChar_y - 74, 5);

    fill(4, 9, 196);
    rect(gameChar_x - 5, gameChar_y - 40, 12, 20, 4);

    fill(0);
    ellipse(gameChar_x + 5, gameChar_y - 57, 8, 5);
    ellipse(gameChar_x + 5, gameChar_y - 48, 8, 6);
  } 
  else if (isFalling) {
    // add your jumping facing forwards code
    fill(160, 0, 170);
    beginShape();
    vertex(gameChar_x + 2, gameChar_y - 22);
    vertex(gameChar_x + 8, gameChar_y - 17);
    vertex(gameChar_x + 3, gameChar_y - 14);
    vertex(gameChar_x + 10, gameChar_y - 14);
    vertex(gameChar_x + 15, gameChar_y - 17);
    vertex(gameChar_x + 9, gameChar_y - 22);
    endShape();

    beginShape();
    vertex(gameChar_x + 1, gameChar_y - 22);
    vertex(gameChar_x - 8, gameChar_y - 17);
    vertex(gameChar_x - 3, gameChar_y - 14);
    vertex(gameChar_x - 10, gameChar_y - 14);
    vertex(gameChar_x - 15, gameChar_y - 17);
    vertex(gameChar_x - 6, gameChar_y - 22);
    endShape();

    fill(155);
    ellipse(gameChar_x + 8, gameChar_y - 12, 10, 5);
    ellipse(gameChar_x - 8, gameChar_y - 12, 10, 5);
    fill(4, 15, 200);
    rect(gameChar_x + 8, gameChar_y - 42, 16, 7, 5, 5);
    rect(gameChar_x - 21, gameChar_y - 42, 16, 7, 5, 5);
    fill(198, 200, 0);
    ellipse(gameChar_x + 20, gameChar_y - 38, 10, 8);
    ellipse(gameChar_x - 20, gameChar_y - 38, 10, 8);

    fill(198, 200, 0);
    ellipse(gameChar_x + 1, gameChar_y - 54, 20, 25);
    triangle(
      gameChar_x - 5,
      gameChar_y - 48,
      gameChar_x + 1,
      gameChar_y - 60,
      gameChar_x - 15,
      gameChar_y - 73
    );
    triangle(
      gameChar_x + 5,
      gameChar_y - 48,
      gameChar_x + 1,
      gameChar_y - 60,
      gameChar_x + 15,
      gameChar_y - 73
    );
    fill(255, 0, 0);
    ellipse(gameChar_x - 15, gameChar_y - 73, 7);
    ellipse(gameChar_x + 15, gameChar_y - 73, 7);

    fill(0);
    ellipse(gameChar_x - 3, gameChar_y - 60, 6, 4);
    ellipse(gameChar_x + 5, gameChar_y - 60, 6, 4);
    ellipse(gameChar_x + 1, gameChar_y - 53, 10, 6);

    fill(4, 9, 196);
    rect(gameChar_x - 6, gameChar_y - 42, 15, 20);
    text("👽", gameChar_x - 6, gameChar_y - 29);
  } 
  else {
 
    // add your standing front facing code
    fill(4, 15, 200);
    rect(gameChar_x + 8, gameChar_y - 42, 8, 30, 5);
    rect(gameChar_x - 12, gameChar_y - 42, 8, 30, 5);
    fill(198, 200, 0);
    ellipse(gameChar_x - 9, gameChar_y - 15, 10, 8);
    ellipse(gameChar_x + 13, gameChar_y - 15, 10, 8);
    fill(160, 0, 170);
    rect(gameChar_x - 4, gameChar_y - 24, 5, 25);
    rect(gameChar_x + 3, gameChar_y - 24, 5, 25);
    fill(155);
    ellipse(gameChar_x + 7, gameChar_y - 1, 10, 5);
    ellipse(gameChar_x - 4, gameChar_y - 1, 10, 5);

    fill(198, 200, 0);
    ellipse(gameChar_x + 1, gameChar_y - 54, 20, 25);
    triangle(
      gameChar_x - 5,
      gameChar_y - 48,
      gameChar_x + 1,
      gameChar_y - 60,
      gameChar_x - 15,
      gameChar_y - 73
    );
    triangle(
      gameChar_x + 5,
      gameChar_y - 48,
      gameChar_x + 1,
      gameChar_y - 60,
      gameChar_x + 15,
      gameChar_y - 73
    );
    fill(255, 0, 0);
    ellipse(gameChar_x - 15, gameChar_y - 73, 7);
    ellipse(gameChar_x + 15, gameChar_y - 73, 7);

    fill(0);
    ellipse(gameChar_x - 3, gameChar_y - 60, 6, 4);
    ellipse(gameChar_x + 5, gameChar_y - 60, 6, 4);
    ellipse(gameChar_x + 1, gameChar_y - 53, 10, 6);

    fill(4, 9, 196);
    rect(gameChar_x - 6, gameChar_y - 42, 15, 20);
    text("👽", gameChar_x - 6, gameChar_y - 29);
  }

}
////////function to draw crown///
function draw_crown(){
      fill(255,215,0);
      rect(collectables[i].x_pos, collectables[i].y_pos,25,15);
      triangle(
                collectables[i].x_pos + 10,
                collectables[i].y_pos ,
                collectables[i].x_pos + 2,
                collectables[i].y_pos -20,
                collectables[i].x_pos ,
                collectables[i].y_pos 
               );

      triangle(
                collectables[i].x_pos + 20,
                collectables[i].y_pos ,
                collectables[i].x_pos + 12,
                collectables[i].y_pos - 20,
                collectables[i].x_pos + 5,
                collectables[i].y_pos 
               );

      triangle(
                collectables[i].x_pos + 15,
                collectables[i].y_pos ,
                collectables[i].x_pos + 22,
                collectables[i].y_pos - 20,
                collectables[i].x_pos + 25,
                collectables[i].y_pos 
               );

      
      fill(200,50,150);
      ellipse(collectables[i].x_pos + 12,collectables[i].y_pos,9,15);
}

/////// function for downstate flagpole//////
function draw_flagpole_down() {
    fill(100,90,100);  
    stroke(1);
    rect(flagpole.x_pos - 23, flagpole.y_pos-20, 50, 20, 60);
    fill(170);
    rect(flagpole.x_pos - 3, flagpole.y_pos-210,10, 190);
    ellipse(flagpole.x_pos + 2, flagpole.y_pos-210, 20);
    fill(200,0,0);
    triangle(flagpole.x_pos - 2, flagpole.y_pos-20, flagpole.x_pos - 2, flagpole.y_pos - 60,  flagpole.x_pos - 60, flagpole.y_pos - 60);
    text("💀",flagpole.x_pos - 21, flagpole.y_pos - 40);
    noStroke();
}

//////// function for reached flagpole////
function draw_flagpole_up() {
    fill(100,90,100);  
    stroke(1);
    rect(flagpole.x_pos - 23, 416, 50, 20, 60);
    fill(170);
    rect(flagpole.x_pos - 3, 226,10, 190);
    ellipse(flagpole.x_pos + 2, 227, 20);
    fill(200,0,0);
    triangle(flagpole.x_pos - 2, flagpole.y_pos - 140, flagpole.x_pos - 2, 251, flagpole.x_pos - 60, flagpole.y_pos - 180);
    text("💀",flagpole.x_pos - 21, flagpole.y_pos - 160);
    noStroke();
}

/////////function to draw ufo and sun
function draw_ufo_sun(){
    //////sun
    fill(253, 184, 19);
    ellipse(width - 100, 75, 55, 55);
    fill(255,180,15,100);
    ellipse(width - 100, 75, 65,65);
    fill(255,170,10,50);
    ellipse(width - 100, 75, 75,75);
    
    ///////draws ufo
    stroke(1);
    textSize(20);
    text("👽",width - 512, 60);
    textSize(0);
    fill(180,180,220,115);
    ellipse(width - 500, 65, 40, 55);
    fill(100,190,240,150);
    noStroke();
    triangle(width - 500, 85, width - 550, 120, width - 450, 120);
    fill(130,130,130);
    stroke(1);
    ellipse(width - 500, 85, 105, 35);
    noStroke();
 
}

function timer () { 
    timePassed = millis() - startTimer;
    timeLeft = (timeLimit - timePassed) / 1000;
  
    if (timeLeft < 0 && !flagpole.isReached) {
        gameOver =  true;
        pause = true
        fill(120,120,120,120)
        rect(0, 0, windowWidth, windowHeight);
        fill(255, 0, 0);
        textFont("Comic sans MS", 95);
        text("☠️ Game Over! ☠️", windowWidth / 7, windowHeight / 3);
        fill(100, 180, 120);
        rect(windowWidth / 2.5, windowHeight / 2.5, 150, 50, 30);
        fill(255, 0, 0);
        textFont("Comic Sans ", 22);
        text(" Click to restart", windowWidth / 2.48, windowHeight / 2.28);
        textSize(20);

        // Check if the mouse is over the restart button
    if (
        mouseX > windowWidth / 2.5 &&
        mouseX < windowWidth / 2.5 + 150 &&
        mouseY > windowHeight / 2.5 &&
        mouseY < windowHeight / 2.5 + 50
        ) {
           fill(150, 220, 180);
           rect(windowWidth / 2.5, windowHeight / 2.5, 150, 50, 30);
           fill(255, 0, 0);
           textFont("Comic Sans", 22);
           fill(0)
           text(" Click to restart", windowWidth / 2.48, windowHeight / 2.28);
           textSize(20);
            // Check for mouse click and restart the game
      if (mouseIsPressed) {
               setup();
            }
        }
    }

    timeLeft = nf(timeLeft, 0, 0)
    if (!pause){
    textFont('Silkscreen', 20)
    stroke(1);
    text("Time remaining:"+ timeLeft, width - 1000 , 80);
    noStroke();
    }
} 

function keyPressed() {
  // if statements to control the animation of the character when
  // keys are pressed.

  //open up the console to see how these work
  console.log("keyPressed: " + key);
  console.log("keyPressed: " + keyCode);

  if (key == "a") {
    isLeft = true;
  } 
  else if (key == "d") {
    isRight = true;
  } 
  else if (!levelComplete){
  if (key == "w" && !isFalling && !levelComplete && !gameOver) {
    gameChar_y -= 130;
   }
  }
}

function keyReleased() {
////////key released statements

  console.log("keyReleased: " + key);
  console.log("keyReleased: " + keyCode);

  if (key == "a") {
    isLeft = false;
  } 
  else if (key == "d") {
    isRight = false;
  }
}
